'use client';

import { useState, useEffect } from 'react';
import { VideoExplanation } from '@/lib/mock-data';
import { getVideosFirestore, addVideoFirestore, deleteVideoFirestore } from '@/lib/firebaseSync';
import { Plus, Trash2, Video, Loader2, CloudCheck } from 'lucide-react';

export default function VideoManagement() {
  const [videos, setVideos] = useState<VideoExplanation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadVideos() {
      try {
        const data = await getVideosFirestore();
        setVideos(data);
      } catch (err) {
        console.error('Error loading videos from Firestore:', err);
      } finally {
        setLoading(false);
      }
    }
    loadVideos();
  }, []);

  const handleDelete = async (id: string) => {
    setVideos(prev => prev.filter(v => v.id !== id));
    try {
      await deleteVideoFirestore(id);
    } catch (err) {
      console.error('Failed to delete video from Firestore:', err);
    }
  };

  const handleAddDemo = async () => {
    const newVid: VideoExplanation = {
      id: `v${Date.now()}`,
      surahId: 21,
      ayahNumber: 1,
      youtubeId: "dQw4w9WgXcQ",
      startTime: 0,
      title: "فيديو تفسير جديد (مخزن بالسحاب)",
      scholar: "د. فاضل السامرائي"
    };

    setVideos(prev => [...prev, newVid]);
    try {
      await addVideoFirestore(newVid);
    } catch (err) {
      console.error('Failed to save video to Firestore:', err);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto font-sans">
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-3xl font-bold text-natural-900">إدارة التفسير المرئي</h1>
            <span className="flex items-center gap-1 text-xs bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full font-semibold">
              <CloudCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Firestore Sync</span>
            </span>
          </div>
          <p className="text-natural-600 text-sm">ربط مقاطع يوتيوب التحليلية بآيات محددة وحفظها بشكل دائم على قواعد بيانات Firebase.</p>
        </div>
        <button 
          onClick={handleAddDemo}
          className="flex items-center gap-2 bg-natural-800 hover:bg-natural-900 text-white px-6 py-3 rounded-xl font-medium transition shadow-sm text-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة فيديو جديد</span>
        </button>
      </div>

      {loading ? (
        <div className="p-16 flex justify-center items-center text-natural-500 gap-3">
          <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
          <span>جاري تحميل الفيديوهات من Firebase Firestore...</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {videos.map(video => (
            <div key={video.id} className="bg-white border border-natural-300 rounded-2xl p-6 flex flex-col md:flex-row gap-6 items-start md:items-center justify-between shadow-sm">
              <div className="flex gap-4 items-center">
                <div className="w-16 h-16 bg-natural-900 rounded-xl flex items-center justify-center text-white shrink-0">
                  <Video className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-natural-900">{video.title}</h3>
                  <p className="text-natural-600 text-xs mt-1">{video.scholar}</p>
                  <div className="mt-3 flex gap-2 text-[10px] font-mono text-natural-700">
                    <span className="bg-natural-100 px-2 py-1 rounded">السورة: {video.surahId}</span>
                    <span className="bg-natural-100 px-2 py-1 rounded">الآية: {video.ayahNumber}</span>
                    <span className="bg-natural-100 px-2 py-1 rounded">البدء: {video.startTime}s</span>
                    <span className="bg-natural-100 px-2 py-1 rounded">ID: {video.youtubeId}</span>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => handleDelete(video.id)}
                className="p-3 text-red-700 hover:bg-red-50 rounded-xl transition border border-transparent hover:border-red-200 cursor-pointer"
                title="حذف الفيديو من Firestore"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}

          {videos.length === 0 && (
            <div className="p-12 text-center text-natural-500 border border-dashed border-natural-300 rounded-2xl bg-natural-50">
              لا توجد فيديوهات مضافة حالياً في Firebase Firestore.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

