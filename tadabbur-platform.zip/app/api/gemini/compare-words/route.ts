import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { word1, word2, contextAyah } = await req.json();

    if (!word1 || !word2 || !contextAyah) {
      return NextResponse.json({ error: "بيانات الكلمات والآية غير مكتملة." }, { status: 400 });
    }

    const prompt = `أنت عالم لغوي وبلاغي متخصص في علوم القرآن الكريم والبيان القرآني. يرجى تقديم تحليل مقارن دقيق ومبسط بين الكلمتين القرآنيتين التاليتين من نفس الآية:

الكلمة الأولى: "${word1.text}" (الجذر: ${word1.root || 'غير محدد'})
الكلمة الثانية: "${word2.text}" (الجذر: ${word2.root || 'غير محدد'})
سياق الآية الكريمة: "${contextAyah}"

يرجى الإجابة بنقاط مقتضبة وواضحة تركز على:
1. الفروق المعجمية والدلالية بين الكلمتين والجذرين.
2. اللمسة البيانية والبلاغية لاستخدام كل كلمة في موقعها.
3. الدلالة السياقية التي توضح الرابط البياني بين الكلمتين في هذه الآية.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: {
          thinkingBudget: 1024
        }
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Compare Words Error:", error);
    return NextResponse.json(
      { error: "تعذر إجراء المقارنة اللغوية حالياً." },
      { status: 500 }
    );
  }
}
