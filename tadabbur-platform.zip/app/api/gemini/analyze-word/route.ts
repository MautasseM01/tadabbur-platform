import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { wordText, root, context } = await req.json();

    const prompt = `أنت عالم لغوي متخصص في القرآن الكريم. يرجى تقديم تحليل مختصر (3-5 جمل) للكلمة القرآنية "${wordText}" والتي جذرها "${root}" في سياق الآية "${context}". اشرح المعنى الدقيق واللمسة البيانية لاستخدام هذه الكلمة بحسب ما ورد من المفسرين المعاصرين المهتمين بالبيان القرآني.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: {
          thinkingBudget: 1024
        }
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json(
      { error: "تعذر تحليل الكلمة في الوقت الحالي. تحقق من إعدادات المفاتيح (API)." },
      { status: 500 }
    );
  }
}
